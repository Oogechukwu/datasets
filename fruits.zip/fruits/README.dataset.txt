# label fruits > Roboflow Instant 1 [Eval]
https://universe.roboflow.com/workshop-avele/label-fruits-i7gwa

Provided by a Roboflow user
License: CC BY 4.0

