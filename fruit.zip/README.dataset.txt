# fruit 1 > Roboflow Instant 1 [Eval]
https://universe.roboflow.com/workshop-avele/fruit-1-rgvfo

Provided by a Roboflow user
License: CC BY 4.0

