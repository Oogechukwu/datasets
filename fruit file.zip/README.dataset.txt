# fruit_gen > Roboflow Instant 1 [Eval]
https://universe.roboflow.com/workshop-avele/fruit_gen-qayfj

Provided by a Roboflow user
License: CC BY 4.0

